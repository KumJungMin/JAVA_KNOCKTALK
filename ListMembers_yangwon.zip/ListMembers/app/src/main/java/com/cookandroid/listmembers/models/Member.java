package com.cookandroid.listmembers.models;

import android.graphics.drawable.Drawable;
import android.widget.Button;

public class Member {
    public String btnStatus;
    public String name;
    public String office;
    public String dp;
    public String studId;
    public String uid;
    public String pushToken;
}
